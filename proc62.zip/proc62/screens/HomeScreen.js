import * as React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import AppHeader from '../components/AppHeader';
import db from '../config';


export default class HomeScreen extends React.Component {
 akilan1Pressed(){
  var akilan1 = db.ref('Akilan/' + '/')
  akilan1.update({
    'absent': 'true'
  })
}

akilan2Pressed(){
  var akilan2 = db.ref('Akilan/' + '/')
  akilan2.update({
    'present': 'true'
  })
}
sahana1Pressed(){
  var sahana1 = db.ref('Sahana/' + '/')
  sahana1.update({
    'absent': 'true'
  })
}

sahana2Pressed(){
  var sahana2 = db.ref('Sahana/' + '/')
  sahana2.update({
    'present': 'true'
  })
}

  goToBuzzerScreen = (buzzercolor) => {
    this.props.navigation.navigate('BuzzerScreen', { color: buzzercolor });
  };
  render() {
    return (
      <View>
        <AppHeader />

        <Text style={styles.studenChartContainer}>Akilan</Text>
        <Text style={styles.studenChartContainer}>Sahana</Text>


        <TouchableOpacity
          style={styles.button}
          onPress={() => {
            this.akilan1Pressed();
          }}>
          <Text style={styles.buttonText}>Absent</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.button }
          onPress={() => {
            this.sahana1Pressed();
          }}>
          <Text style={styles.buttonText}>Absent</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.button2}
          onPress={() => {
           this.akilan2Pressed();
          }}>
          <Text style={styles.button2Text}>Present</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.button2}
          onPress={() => {
             this.sahana2Pressed();
          }}>
          <Text style={styles.button2Text}>Present</Text>
        </TouchableOpacity>


        <TouchableOpacity
          style={styles.button3}
          onPress={() => {
            this.goToBuzzerScreen('yellow');
          }}>
          <Text style={styles.button3Text}>Submit</Text>
        </TouchableOpacity>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  studenChartContainer: {
     flexDirection: 'row',
     padding: 10,
     alignItems: 'center',
     margin: 20
  },
  button: {
    justifyContent: 'center',
    alignSelf: 'center',
    borderWidth: 2,
    borderRadius: 5,
    marginTop: -70,
    marginLeft: 200,
    width: 100,
    height: 30,
    backgroundColor: 'black'
  },
  buttonText: {
    textAlign: 'center',
    color: 'red',
  },
  button2: {
    justifyContent: 'center',
    alignSelf: 'center',
    borderWidth: 2,
    borderRadius: 5,
    marginBottom: -70,
    marginLeft: -30,
    width: 100,
    height: 30,
    backgroundColor: 'black'
  },
  button2Text: {
    textAlign: 'center',
    color: 'green',
  },
  button3: {
    justifyContent: 'center',
    alignSelf: 'center',
    borderWidth: 2,
    borderRadius: 5,
    marginTop: 200,
    marginLeft: 40,
    width: 200,
    height: 50,
    backgroundColor: 'black',
  },
   button3Text: {
    textAlign: 'center',
    color: 'white',
  },
 
});