import { initializeApp } from "firebase";
// TODO: Add SDKs for Firebase products that you want to use


// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCxPQPJEzjG-HRuhy7hhrGqik11-QFYub0",
  authDomain: "c1-4b685.firebaseapp.com",
  databaseURL: "https://c1-4b685-default-rtdb.firebaseio.com",
  projectId: "c1-4b685",
  storageBucket: "c1-4b685.appspot.com",
  messagingSenderId: "385506807637",
  appId: "1:385506807637:web:9246e1dd59295e319669dc"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export default app.database();

